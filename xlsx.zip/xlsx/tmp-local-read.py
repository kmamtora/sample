import xlrd
from datetime import datetime
from collections import OrderedDict
import json
from elasticsearch import Elasticsearch
from elasticsearch import helpers
import logging

logging.basicConfig(filename='app.txt', filemode='w', format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
_listFiles = []
es=Elasticsearch([{'host':'localhost','port':9200}])


def fnPath():
	_listFiles.append("99hightide-customers")
	_listFiles.append("birthdates")
	_listFiles.append("checkins")
	_listFiles.append("Current Activty Report")
	_listFiles.append("detailedsalesreport")
	_listFiles.append("Inventory Purchases")
	_listFiles.append("Patient data")
	_listFiles.append("Proteus-Inventory-2019-11-19")
	_listFiles.append("Proteus420 - Monthly Grams Report_USELESS")
	_listFiles.append("Sales by Zipcode")
	_listFiles.append("Total Patient Sales")
	return _listFiles

def fnLoop():
	fnPath()
	for x in _listFiles:
		indexName = x.replace(' ','-').lower()
		_query = {
			"query": {
				"match": {
					"flag": "1"
				}
			},
			"sort":[
				{
					"timestamp": {
						"order": "asc"
					}
				}
			]
		}
		results = helpers.scan(es, query=_query, index=indexName)
		logFile = "log/" + indexName + ".txt"
		for item in results:
			with open(logFile, 'a+') as f:
				f.write(json.dumps(item))

		

fnLoop()



